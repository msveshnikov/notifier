module JPicker
  module Rails
    VERSION = "0.1"
  end
end
