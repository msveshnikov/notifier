require "jPicker-rails/version"

module JPicker
  module Rails
    class Engine < ::Rails::Engine
    end
  end
end